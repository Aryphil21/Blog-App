"""Custom JSON formatter for structured logging."""

from logging import LogRecord
from datetime import datetime, timezone
from pythonjsonlogger import jsonlogger


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """JSON formatter that enforces consistent field ordering and enriches logs."""

    def add_fields(
        self, log_record: dict, record: LogRecord, message_dict: dict
    ) -> None:
        super().add_fields(log_record, record, message_dict)

        order_list = [
            "timestamp",
            "level",
            "appName",
            "appVersion",
            "location",
            "thread",
            "server",
            "message",
            "correlationId",
            "traceId",
            "environment",
            "clientId",
        ]

        log_record.update(
            {
                "timestamp": datetime.now(timezone.utc).strftime(
                    "%Y-%m-%dT%H:%M:%S.%fZ"
                ),
                "level": record.levelname,
                "location": f"{record.filename}:{record.lineno}",
                "thread": record.threadName,
                "server": record.pathname,
                "message": record.getMessage(),
                "correlationId": getattr(record, "correlationId", ""),
                "traceId": getattr(record, "traceId", ""),
                "clientId": getattr(record, "clientId", ""),
                "appName": getattr(record, "appName", ""),
                "appVersion": getattr(record, "appVersion", ""),
                "environment": getattr(record, "environment", ""),
            }
        )

        sorted_log_record = {
            key: log_record[key] for key in order_list if key in log_record
        }

        log_record.clear()
        log_record.update(sorted_log_record)
