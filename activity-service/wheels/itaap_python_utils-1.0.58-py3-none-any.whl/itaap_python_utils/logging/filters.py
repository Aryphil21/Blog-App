"""Logging filter to add application context to log records."""

import logging


class AppContextFilter(logging.Filter):
    """Filter that enriches log records with application context metadata."""

    def __init__(self, app_name: str, app_version: str, environment: str) -> None:
        super().__init__()
        self.app_name = app_name
        self.app_version = app_version
        self.environment = environment

    def filter(self, record: logging.LogRecord) -> bool:
        record.appName = self.app_name
        record.appVersion = self.app_version
        record.environment = self.environment
        return True
