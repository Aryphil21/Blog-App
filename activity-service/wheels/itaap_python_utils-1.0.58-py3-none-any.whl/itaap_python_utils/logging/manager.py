"""Logger initialization and management utility."""

import uuid
import logging
from typing import Optional
from .formatter import CustomJsonFormatter
from .filters import AppContextFilter


class LogManager:
    """Manages application-wide logging configuration and logger instances."""

    @staticmethod
    def init_logger(
        app_name: str, app_version: str, environment: str, log_level: str = "INFO"
    ) -> None:
        """Initialize root logger with JSON formatting and app context."""
        root_logger = logging.getLogger()
        if not any(
            isinstance(handler, logging.StreamHandler)
            for handler in root_logger.handlers
        ):
            stream_handler = logging.StreamHandler()
            formatter = CustomJsonFormatter()
            stream_handler.setFormatter(formatter)

            numeric_level = getattr(logging, log_level.upper(), logging.INFO)
            root_logger.setLevel(numeric_level)

            stream_handler.addFilter(
                AppContextFilter(app_name, app_version, environment)
            )
            root_logger.addHandler(stream_handler)

    @staticmethod
    def get_logger(
        correlation_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        client_id: Optional[str] = None,
    ) -> logging.LoggerAdapter:
        """Get logger instance with trace context."""
        logger = logging.getLogger(__name__)
        extra = {
            "correlationId": correlation_id or str(uuid.uuid4()),
            "traceId": trace_id or "",
            "clientId": client_id or "",
        }
        return logging.LoggerAdapter(logger, extra)
