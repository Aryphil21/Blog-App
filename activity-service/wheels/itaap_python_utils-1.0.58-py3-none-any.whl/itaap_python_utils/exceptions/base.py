"""Base exceptions"""


class ServiceException(Exception):
    """Base exception for all service-related errors."""

    def __init__(
        self,
        error_code: int,
        error_desc: str,
        status_code: int,
        correlation_id: str = None,
    ):
        self.error_code = error_code
        self.error_desc = error_desc
        self.correlation_id = correlation_id
        self.status_code = status_code
        super().__init__(self.error_desc)
