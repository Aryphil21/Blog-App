"""Global exception handler for standardized error responses."""

from typing import Tuple
from .base import ServiceException
from .models import ErrorResponse


class GlobalExceptionHandler:
    """Global exception handler for standardized error responses."""

    def __init__(self, correlation_id_header: str = "X-Correlation-ID"):
        """
        Initialize the exception handler.

        Args:
            correlation_id_header: HTTP header name for correlation ID
        """
        self.correlation_id_header = correlation_id_header

    def handle_exception(
        self, exc: Exception, correlation_id: str = None
    ) -> Tuple[ErrorResponse, int]:
        """
        Handle different types of exceptions and return standardized error response.

        Args:
            exc: Exception to handle
            correlation_id: Optional correlation ID for tracking

        Returns:
            Tuple[ErrorResponse, int]: Error response and HTTP status code
        """
        if isinstance(exc, ServiceException):
            return self._handle_service_exception(exc, correlation_id)

        return self._handle_uncaught_exception(exc, correlation_id)

    def _handle_service_exception(
        self, exc: ServiceException, correlation_id: str
    ) -> Tuple[ErrorResponse, int]:
        return (
            ErrorResponse(
                error_code=exc.error_code,
                error_desc=exc.error_desc,
                correlation_id=correlation_id or exc.correlation_id,
            ),
            exc.status_code,
        )

    def _handle_uncaught_exception(
        self, exc: Exception, correlation_id: str
    ) -> Tuple[ErrorResponse, int]:

        status_code = 500
        reason = "Internal Server Error"

        # Check direct status_code attribute
        if hasattr(exc, "status_code"):
            status_code = exc.status_code
        # Check response.status_code (for requests/httpx exceptions)
        elif hasattr(exc, "response") and hasattr(exc.response, "status_code"):
            status_code = exc.response.status_code
        # For aiohttp which uses 'status' instead of 'status_code'
        elif hasattr(exc, "status"):
            status_code = exc.status

        # Get reason from exception
        if hasattr(exc, "reason"):
            base_reason = exc.reason
        elif hasattr(exc, "detail"):  # FastAPI often uses 'detail'
            base_reason = exc.detail
        elif hasattr(exc, "message"):  # Some exceptions use 'message'
            base_reason = exc.message
        else:
            base_reason = str(exc) or reason  # Use string representation if not empty

        reason = f"{exc.__class__.__name__} : {base_reason}"

        return (
            ErrorResponse(
                error_code=status_code, error_desc=reason, correlation_id=correlation_id
            ),
            status_code,
        )
