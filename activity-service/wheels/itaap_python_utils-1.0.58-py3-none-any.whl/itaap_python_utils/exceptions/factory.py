"""Factory for creating service-level exceptions."""

from typing import Type, Dict
from dataclasses import dataclass
from .base import ServiceException


@dataclass(frozen=True)
class ErrorConfig:
    """Configuration for a service error type."""

    name: str
    error_code: int
    template: str
    status_code: int


class ServiceErrorsFactory:
    """Factory for creating service-level exceptions."""

    def __init__(self):
        self._error_registry: Dict[str, Type[ServiceException]] = {}

    def register_error(
        self, error_name: str, error_code: int, error_desc_template: str, status_code
    ) -> Type[ServiceException]:
        """
        Register a new service exception type.

        Args:
            error_name: Name of the error class to create
            error_code: Numeric error code for this error type
            error_desc_template: Template string for error description
            status_code: Response status code

        Returns:
            Type[ServiceException]: New exception class
        """

        def __init__(self, **kwargs):
            error_desc = error_desc_template.format(**kwargs)
            ServiceException.__init__(self, error_code, error_desc, status_code)
            self.error_code = error_code
            self.error_desc = error_desc
            self.status_code = status_code

        exception_class = type(
            error_name,
            (ServiceException,),
            {
                "__init__": __init__,
                "error_code": error_code,
                "error_desc_template": error_desc_template,
                "status_code": status_code,
            },
        )

        self._error_registry[error_name] = exception_class
        return exception_class

    def get_error(self, error_name: str) -> Type[ServiceException]:
        """
        Get a registered service exception type.

        Args:
            error_name: Name of the registered error class

        Returns:
            Type[ServiceException]: Registered exception class

        Raises:
            ValueError: If error_name is not registered
        """
        if error_name not in self._error_registry:
            raise ValueError(f"Error type '{error_name}' not registered")
        return self._error_registry[error_name]

    def raise_exception(self, error: ErrorConfig, **kwargs):
        """
        Raise a service exception.

        Args:
            error: ErrorConfig instance from ServiceErrors enum
            **kwargs: Parameters for error template
        """
        exception_class = self.get_error(error.name)
        raise exception_class(**kwargs)
