"""Error response models."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ErrorResponse:
    """Standard error response model."""

    error_code: int
    error_desc: str
    correlation_id: Optional[str] = None
