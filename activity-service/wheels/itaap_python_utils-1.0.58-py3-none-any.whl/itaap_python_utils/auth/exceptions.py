"""Custom exceptions for JWT token validation errors."""


class TokenValidationError(Exception):
    """Base exception for token validation errors"""


class InvalidSignatureError(TokenValidationError):
    """Exception raised when signature verification is failed"""


class TokenExpiredError(TokenValidationError):
    """Exception raised when token has expired"""


class InvalidTokenFormatError(TokenValidationError):
    """Exception raised when token format is invalid"""


class InvalidAudienceError(TokenValidationError):
    """Exception raised when audience doesn't match"""


class InvalidRoleError(TokenValidationError):
    """Exception raised when required role is not present"""


class InvalidTenantError(TokenValidationError):
    """Exception raised when token is not a philips issued one"""
