"""This module provides functionality for validating JWT tokens according to specific requirements,
including audience validation, role verification, tenant checks, and expiration verification.
"""

import ssl
import jwt
from jwt import PyJWKClient
from .exceptions import (
    InvalidTokenFormatError,
    InvalidSignatureError,
    TokenExpiredError,
    InvalidAudienceError,
    InvalidRoleError,
    InvalidTenantError,
)

PHILIPS_TENANT = "1a407a2d-7675-4d17-8692-b3ac285306e4"


class JWTTokenChecker:
    """JWT token validation utility."""

    def __init__(self, algorithm: str, jwks_url: str, audience: str):
        """Initialize the JWT token checker.

        Args:
            algorithm: Token signing algorithm (e.g., 'RS256')
            jwks_url: URL of the JWKS endpoint
            audience: Expected audience value
        """
        self.algorithm = algorithm
        self.jwks_url = jwks_url
        self.audience = audience

    def decode_and_verify_token(self, token: str) -> dict:
        """Decode JWT token with signature verification"""
        try:
            public_key = self.get_signing_key(token)

            return jwt.decode(
                token, key=public_key, algorithms=self.algorithm, audience=self.audience
            )
        except jwt.InvalidSignatureError as e:
            raise InvalidSignatureError("Invalid Signature") from e
        except jwt.ExpiredSignatureError as e:
            raise TokenExpiredError("Token has expired") from e
        except jwt.InvalidAudienceError as e:
            raise InvalidAudienceError("Invalid audience") from e
        except jwt.InvalidTokenError as e:
            raise InvalidTokenFormatError(f"Invalid token format: {str(e)}") from e

    def get_signing_key(self, token: str) -> dict:
        """Get the signing key from JWKS endpoint."""

        try:
            jwks_client = PyJWKClient(self.jwks_url)
            if jwks_client:
                signing_key = jwks_client.get_signing_key_from_jwt(token)
                return signing_key.key
        except Exception as e:
            raise InvalidSignatureError(f"Failed to get signing key: {str(e)}") from e

    def verify_tenant(self, token_payload: dict, expected_tenant: str) -> bool:
        """Verify if it is a philips issued token"""
        token_issuer = token_payload.get("iss")
        if token_issuer is None:
            raise InvalidTokenFormatError("Token has no issuer claim")
        token_tenant = token_payload.get("iss").split("/")[-2]
        return token_tenant == expected_tenant

    def verify_roles(self, token: str, required_role: str) -> bool:
        """Verify if token has the required role."""
        payload = self.decode_and_verify_token(token)
        token_roles = payload.get("roles")
        if token_roles is None:
            raise InvalidTokenFormatError("Token has no roles claim")

        if required_role not in token_roles:
            raise InvalidRoleError("Insufficient Permissions")
        return True

    def validate_token(self, token: str) -> bool:
        """Perform all token validations."""
        token_payload = self.decode_and_verify_token(token)

        if not self.verify_tenant(token_payload, PHILIPS_TENANT):
            raise InvalidTenantError("Invalid tenant")

        return token_payload.get("appid")
